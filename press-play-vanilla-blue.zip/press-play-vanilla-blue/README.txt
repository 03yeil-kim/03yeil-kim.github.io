PRESS PLAY. — Kim Yeil

Open index.html in a local web server.
For example: python3 -m http.server 8000
Then visit http://localhost:8000
